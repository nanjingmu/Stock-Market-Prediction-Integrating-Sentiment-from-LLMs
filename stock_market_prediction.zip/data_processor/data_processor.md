# Data Processing Pipeline

This document explains how to use the scripts in the `data_processor` folder to prepare data for the sentiment‑enhanced stock prediction models.  The pipeline is inspired by the structure of the [GitHub repository referenced by the instructor](https://github.com/nanjingmu/0905/tree/main/data_processor).

## Directory layout

- **`news_data_raw/`** and **`stock_price_data_raw/`** — place your downloaded raw CSV files here.  Each CSV should contain at least a `Date` column; news files should additionally contain a `Text` column with the article body and a `Mark` column indicating relevance (1 = relevant, 0 = irrelevant).
- **`news_data_preprocessed/`** and **`stock_price_data_preprocessed/`** — will be created by `preprocess.py`.  They contain the same data as the raw folders but with all timestamps normalised to UTC and dates sorted in descending order.
- **`news_data_summarized/`** — created by `summarize.py` to store summarised text.  Each file has a `New_text` column containing a short summary of the article and retains other important columns (e.g. `Date`, `Mark`, `Url`).
- **`news_data_sentiment_scored_by_gpt/`** — created by `score_by_gpt.py`.  These CSVs extend the summarised files with a `Sentiment_gpt` column representing sentiment on a 1–5 scale (1 = negative, 3 = neutral, 5 = positive).
- **`gpt_sentiment_price_news_integrate/`** — produced by `price_news_integrate.py`.  Each CSV combines the corresponding stock’s price history with the averaged daily sentiment score.  Missing dates are filled using an exponential decay rule and a `News_flag` indicates whether a news item occurred on that date.

## Scripts

### 1. `preprocess.py`

Use this script to normalise dates and times across your raw datasets.  It converts strings containing timezone abbreviations (e.g. `EDT`, `EST`) or various date formats into a uniform UTC timestamp.  All converted dates are stored in the `Date` column and the output is sorted by date descending.  Run it with:

```bash
python data_processor/preprocess.py
```

### 2. `summarize.py`

This script uses an extractive summarisation technique (latent semantic analysis via the **sumy** library) to compress each news article into a short summary.  It takes the full text from the `Text` column, identifies key sentences (weighted by stock ticker keywords) and writes the result into a new column `New_text`.  Only articles marked with `Mark == 1` are kept.  Run:

```bash
python data_processor/summarize.py
```

### 3. `score_by_gpt.py`

After summarisation, sentiment scores need to be generated using a large language model.  This script contains a function `get_sentiment()` that sends the summarised text to the OpenAI API and expects a comma‑separated string of integers between 1 and 5.  The result is parsed into a list and stored in the `Sentiment_gpt` column.  You must set your OpenAI API key in the script before running it.  Because network calls are disabled in this environment, this script serves as a template only:

```bash
python data_processor/score_by_gpt.py
```

When running locally, you can process all news files in a folder or a single ticker symbol by modifying the `__main__` block at the bottom of the script.  Partial results are written incrementally so that you can resume processing after hitting rate limits.

### 4. `price_news_integrate.py`

Finally, merge the pre‑processed price and news datasets.  The script reads each stock’s price file and its corresponding sentiment file, aligns the dates to midnight, calculates the average sentiment score per day and fills missing days using an exponential decay rule.  It also scales the sentiment to a [0, 1] range and outputs a `News_flag` column that indicates whether at least one news article was present on a given day.  Execute it via:

```bash
python data_processor/price_news_integrate.py
```

The resulting CSVs in `gpt_sentiment_price_news_integrate/` provide the feature set needed for model training.

---

If you add or rename files or columns, be sure to adjust the script paths and column names accordingly.  These scripts are meant to be a starting point; feel free to extend them with additional preprocessing logic such as scaling numerical features, handling outliers, or augmenting the sentiment analysis with alternative models.