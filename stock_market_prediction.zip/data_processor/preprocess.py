"""
Normalize date and time formats in raw price and news CSV files.

This script converts a variety of timestamp strings (e.g. ``"September 12, 2023 — 06:15 pm EDT"`` or ``"2021/4/5"``) into a uniform UTC time format.  It outputs the cleaned CSV files into dedicated folders for further processing.

The logic here follows the example provided in the reference repository, with a few simplifications.  Adjust the list of date formats in ``convert_to_utc`` as needed to match your data sources.
"""

import os
from datetime import datetime, timedelta
import pandas as pd


def convert_to_utc(time_str: str) -> str:
    """Convert a date/time string to a UTC ISO format.

    Supports several human‑readable formats and timezone abbreviations.  If a
    recognised timezone suffix is present (e.g. ``"EDT"`` or ``"EST"``), an
    offset is applied.  Otherwise a zero offset is assumed.  If no format
    matches, the original string is returned unchanged.
    """
    # Remove timezone abbreviations and set the corresponding offset
    offset = timedelta(0)
    cleaned = time_str.strip()
    if cleaned.endswith(" EDT"):
        cleaned = cleaned.replace(" EDT", "")
        offset = timedelta(hours=-4)
    elif cleaned.endswith(" EST"):
        cleaned = cleaned.replace(" EST", "")
        offset = timedelta(hours=-5)

    # Possible datetime formats (extend as needed)
    formats = [
        "%B %d, %Y — %I:%M %p",  # "September 12, 2023 — 06:15 pm"
        "%b %d, %Y %I:%M%p",     # "Nov 14, 2023 7:35AM"
        "%d-%b-%y",             # "6-Jan-22"
        "%Y-%m-%d",             # "2021-4-5"
        "%Y/%m/%d",             # "2021/4/5"
        "%b %d, %Y",            # "DEC 7, 2023"
    ]

    for fmt in formats:
        try:
            dt = datetime.strptime(cleaned, fmt)
            # If the format contains only a date (no time), do not apply offset
            apply_offset = "%H" in fmt or "%I" in fmt
            dt_utc = dt + (offset if apply_offset else timedelta(0))
            return dt_utc.strftime("%Y-%m-%d %H:%M:%S UTC")
        except ValueError:
            continue
    # Return the original string if no format matched
    return cleaned


def process_folder(folder_path: str, saving_path: str) -> None:
    """Convert the `Date` column in all CSVs within `folder_path` to UTC.

    Writes cleaned files into `saving_path`.  The function silently skips
    non‑CSV files.  Existing files in `saving_path` will be overwritten.
    """
    os.makedirs(saving_path, exist_ok=True)
    for csv_file in [f for f in os.listdir(folder_path) if f.endswith(".csv")]:
        file_path = os.path.join(folder_path, csv_file)
        print(f"Processing {csv_file}...")
        df = pd.read_csv(file_path, on_bad_lines="warn")
        # Normalise column capitalisation
        df.columns = df.columns.str.capitalize()
        if "Datetime" in df.columns:
            df.rename(columns={"Datetime": "Date"}, inplace=True)
        if "Date" not in df.columns:
            print(f"Skipping {csv_file}: no 'Date' column present")
            continue
        # Convert dates
        df["Date"] = df["Date"].astype(str).apply(convert_to_utc)
        # Parse as pandas datetime (UTC) for sorting
        df["Date"] = pd.to_datetime(df["Date"], errors="coerce", utc=True)
        df = df.sort_values(by="Date", ascending=False)
        df.to_csv(os.path.join(saving_path, csv_file), index=False)
        print(f"Saved cleaned file to {saving_path}/{csv_file}")


if __name__ == "__main__":
    # Define relative paths to raw and preprocessed data
    news_raw = os.path.join(os.path.dirname(__file__), "news_data_raw")
    news_preprocessed = os.path.join(os.path.dirname(__file__), "news_data_preprocessed")
    stock_raw = os.path.join(os.path.dirname(__file__), "stock_price_data_raw")
    stock_preprocessed = os.path.join(os.path.dirname(__file__), "stock_price_data_preprocessed")

    process_folder(news_raw, news_preprocessed)
    process_folder(stock_raw, stock_preprocessed)