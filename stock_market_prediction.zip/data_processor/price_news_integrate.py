"""
Merge pre‑processed stock price and sentiment‑scored news data.

Each stock symbol is represented by two CSV files: a price file in
``stock_price_data_preprocessed/`` and a sentiment file in
``news_data_sentiment_scored_by_gpt/``.  This script aligns the dates,
averages daily sentiment, fills gaps using an exponential decay rule and
produces a merged DataFrame with a ``Scaled_sentiment`` column on a 0–1 scale.

The resulting CSVs are written to ``gpt_sentiment_price_news_integrate/``.
"""

import os
from typing import Tuple

import numpy as np
import pandas as pd


def convert_to_utc(df: pd.DataFrame, date_column: str) -> pd.DataFrame:
    """Ensure the date column is timezone‑aware and in UTC."""
    df[date_column] = pd.to_datetime(df[date_column], errors="coerce")
    if df[date_column].dt.tz is None:
        df[date_column] = df[date_column].dt.tz_localize("UTC")
    return df


def fill_missing_dates_with_exponential_decay(
    df: pd.DataFrame,
    date_column: str,
    sentiment_column: str,
    decay_rate: float = 0.05,
) -> pd.DataFrame:
    """Fill missing dates by exponentially decaying the last valid sentiment value.

    If no previous sentiment exists, missing dates are left as NaN.  The
    ``News_flag`` column indicates whether a news item occurred on that date (1)
    or was imputed (0).
    """
    df[date_column] = pd.to_datetime(df[date_column], errors="coerce")
    # Create complete date range
    full_range = pd.date_range(start=df[date_column].min(), end=df[date_column].max())
    full_df = pd.DataFrame({date_column: full_range})
    full_df = pd.merge(full_df, df, on=date_column, how="left")
    full_df['News_flag'] = full_df[sentiment_column].notna().astype(int)
    last_sentiment = None
    last_date = None
    for idx, row in full_df.iterrows():
        if pd.isna(row[sentiment_column]):
            if last_sentiment is not None:
                days_since = (row[date_column] - last_date).days
                decayed = last_sentiment * np.exp(-decay_rate * days_since)
                full_df.at[idx, sentiment_column] = decayed
                full_df.at[idx, 'News_flag'] = 0
        else:
            last_sentiment = row[sentiment_column]
            last_date = row[date_column]
    return full_df


def integrate_data(
    stock_price_df: pd.DataFrame,
    news_df: pd.DataFrame,
    sentiment_column: str = 'Sentiment_gpt',
) -> Tuple[int, pd.DataFrame]:
    """Merge price and news data for a single stock symbol.

    Returns a flag indicating whether there are sufficient data points for
    modelling (1 = yes, 0 = no) along with the merged DataFrame.  A day is
    considered insufficient if fewer than 333 trading days are present (as an
    example threshold).
    """
    stock = convert_to_utc(stock_price_df.copy(), 'Date')
    news = convert_to_utc(news_df.copy(), 'Date')
    # Normalise to midnight to ensure date alignment
    stock['Date'] = pd.to_datetime(stock['Date']).dt.normalize()
    news['Date'] = pd.to_datetime(news['Date']).dt.normalize()
    stock.set_index('Date', inplace=True)
    news.set_index('Date', inplace=True)
    # Cap the sentiment values (if using 1–5 scale)
    news[sentiment_column] = news[sentiment_column].clip(lower=1, upper=5)
    # Daily average sentiment
    avg_sentiment = news.groupby('Date')[sentiment_column].mean().reset_index()
    # Fill missing dates with exponential decay
    avg_sentiment_filled = fill_missing_dates_with_exponential_decay(avg_sentiment, 'Date', sentiment_column)
    # Merge with price data
    merged = pd.merge(stock, avg_sentiment_filled, on='Date', how='left')
    # Default missing sentiment to neutral (3)
    merged[sentiment_column].fillna(3, inplace=True)
    # Drop rows without a News_flag (these correspond to dates prior to the first news item)
    merged = merged.dropna(subset=['News_flag'])
    # Filter out zero sentiment rows (if any)
    merged = merged[merged[sentiment_column] != 0]
    # Scale sentiment to [0, 1]
    merged['Scaled_sentiment'] = merged[sentiment_column].apply(lambda x: (x - 1) / 4)
    sufficient = 1 if len(merged) >= 333 else 0
    return sufficient, merged


def start_integration(stock_folder: str, news_folder: str, output_folder: str, sentiment_column: str = 'Sentiment_gpt') -> None:
    """Iterate over stock CSVs and integrate them with matching news CSVs."""
    os.makedirs(output_folder, exist_ok=True)
    stock_files = [f for f in os.listdir(stock_folder) if f.endswith('.csv')]
    for price_file in stock_files:
        price_path = os.path.join(stock_folder, price_file)
        news_path = os.path.join(news_folder, price_file)
        if not os.path.isfile(news_path):
            print(f"No matching news file for {price_file}")
            continue
        stock_df = pd.read_csv(price_path)
        news_df = pd.read_csv(news_path)
        # Normalise column names
        stock_df.columns = stock_df.columns.str.capitalize()
        news_df.columns = news_df.columns.str.capitalize()
        flag, merged_df = integrate_data(stock_df, news_df, sentiment_column)
        out_path = os.path.join(output_folder, price_file)
        merged_df.to_csv(out_path, index=False)
        if flag == 0:
            print(f"Warning: {price_file} contains fewer than 333 records; you may want to exclude it from modelling.")
        print(f"Saved integrated data to {out_path}")


if __name__ == "__main__":
    stock_preprocessed = os.path.join(os.path.dirname(__file__), 'stock_price_data_preprocessed')
    news_scored = os.path.join(os.path.dirname(__file__), 'news_data_sentiment_scored_by_gpt')
    output_dir = os.path.join(os.path.dirname(__file__), 'gpt_sentiment_price_news_integrate')
    start_integration(stock_preprocessed, news_scored, output_dir)