"""
Assign sentiment scores to summarised news using a large language model.

This script demonstrates how you might integrate an LLM (e.g. OpenAI's GPT models)
to score news articles on a 1–5 scale (1 = negative, 3 = neutral, 5 = positive).
It reads summarised news CSVs from ``news_data_summarized/`` and writes the
results to ``news_data_sentiment_scored_by_gpt/``.  Because the OpenAI API
requires an internet connection and valid API credentials, this script will not
function in the current environment.  Use it as a template when running on
your own machine.
"""

import os
import time
from typing import List

import numpy as np
import pandas as pd

try:
    import openai
    from openai import OpenAI
except ImportError:
    openai = None  # type: ignore
    OpenAI = None  # type: ignore

# Replace with your actual OpenAI API key
API_KEY = "sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"

def get_sentiment(symbol: str, *texts: str) -> List[int]:
    """Call the OpenAI API to score a batch of summarised news snippets.

    The model is prompted with the stock symbol and up to four pieces of news.
    It should return a comma‑separated string of integers between 1 and 5.
    """
    if openai is None or OpenAI is None:
        raise RuntimeError("openai package is not installed; cannot score sentiment")
    # Filter out empty texts
    texts = [text for text in texts if text]
    num_text = len(texts)
    # Build conversation for chat model
    text_content = " ".join([f"### News to Stock Symbol -- {symbol}: {text}" for text in texts])
    conversation = [
        {
            "role": "system",
            "content": (
                "Forget all your previous instructions. You are a financial expert "
                "with stock recommendation experience. Based on a specific stock, score "
                "from 1 to 5, where 1 is negative, 2 is somewhat negative, 3 is neutral, "
                "4 is somewhat positive, 5 is positive. "
                f"{num_text} summarised news will be passed in each time, you will give "
                "score in format as shown below in the response from assistant."
            ),
        },
        {
            "role": "user",
            "content": (
                "News to Stock Symbol -- AAPL: Apple (AAPL) increase 22% ### "
                "News to Stock Symbol -- AAPL: Apple (AAPL) price decreased 30% ### "
                "News to Stock Symbol -- MSFT: Microsoft (MSFT) price has no change"
            ),
        },
        {"role": "assistant", "content": "5, 1, 3"},
        {
            "role": "user",
            "content": (
                "News to Stock Symbol -- AAPL: Apple (AAPL) announced iPhone 15 ### "
                "News to Stock Symbol -- AAPL: Apple (AAPL) will release VisionPro on Feb 2, 2024"
            ),
        },
        {"role": "assistant", "content": "4, 4"},
        {"role": "user", "content": text_content},
    ]
    # Initialise client
    client = OpenAI(api_key=API_KEY)
    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=conversation,
            temperature=0.0,
            max_tokens=50,
        )
        content = response.choices[0].message.content
    except Exception as e:
        print(f"OpenAI API error: {e}")
        return [np.nan] * num_text
    sentiments: List[int] = []
    for sentiment in content.split(','):
        try:
            sentiments.append(int(sentiment.strip()))
        except ValueError:
            sentiments.append(np.nan)
    return sentiments


def from_csv_get_sentiment(df: pd.DataFrame, symbol: str, saving_path: str, batch_size: int = 4) -> pd.DataFrame:
    """Iteratively populate the `Sentiment_gpt` column for each row in `df`.

    The function processes the DataFrame in batches to stay within API rate
    limits.  After each batch, the partially filled DataFrame is saved to
    disk so that progress is not lost if the process is interrupted.
    """
    # Sort so that unprocessed rows appear last
    df.sort_values(by='Sentiment_gpt', ascending=False, na_position='last', inplace=True)
    for i in range(0, len(df), batch_size):
        # Skip already processed rows
        if df.loc[i:min(i + batch_size - 1, len(df) - 1), 'Sentiment_gpt'].notna().all():
            continue
        batch_texts = [df.loc[j, 'Lsa_summary'] if j < len(df) else "" for j in range(i, i + batch_size)]
        sentiments = get_sentiment(symbol, *batch_texts)
        for k, sentiment in enumerate(sentiments):
            if i + k < len(df):
                df.loc[i + k, 'Sentiment_gpt'] = sentiment
        # Save progress
        df_filtered = df[['Date', 'Url', 'Sentiment_gpt']].copy()
        df_filtered.sort_values(by='Sentiment_gpt', ascending=False, na_position='last', inplace=True)
        df_filtered.to_csv(saving_path, index=False)
    return df


def reproduce(folder_path: str, ticker: str, saving_path: str, batch_size: int) -> None:
    """Process a single summarised news file and write sentiment scores."""
    file_path = os.path.join(folder_path, f"{ticker}.csv")
    if not os.path.isfile(file_path):
        print(f"File {file_path} does not exist")
        return
    try:
        df = pd.read_csv(file_path, encoding="utf-8")
    except UnicodeDecodeError:
        df = pd.read_csv(file_path, encoding="ISO-8859-1")
    df.columns = df.columns.str.capitalize()
    if 'Sentiment_gpt' not in df.columns:
        df['Sentiment_gpt'] = np.nan
    # Rename summary column if necessary
    if 'New_text' in df.columns:
        df.rename(columns={'New_text': 'Lsa_summary'}, inplace=True)
    if df['Sentiment_gpt'].isnull().any():
        bs = batch_size
        while bs > 0 and df['Sentiment_gpt'].isnull().any():
            df = from_csv_get_sentiment(df, ticker, os.path.join(saving_path, f"{ticker}.csv"), bs)
            bs -= 1
        if df['Sentiment_gpt'].isnull().any():
            print(f"Unfinished: {ticker}")
        else:
            print(f"Finished: {ticker}")
    else:
        print(f"File {ticker} already scored")


if __name__ == "__main__":
    # Only runs when executed directly.  Modify the following paths to suit your environment.
    news_summarized = os.path.join(os.path.dirname(__file__), "news_data_summarized")
    news_scored = os.path.join(os.path.dirname(__file__), "news_data_sentiment_scored_by_gpt")
    os.makedirs(news_scored, exist_ok=True)
    # Example usage: process a single ticker interactively
    ticker = input("Enter a stock ticker symbol (e.g. AAPL): ").strip().upper()
    reproduce(news_summarized, ticker, news_scored, batch_size=4)