"""
Summarise news articles using latent semantic analysis (LSA).

This script reads all CSV files in ``news_data_preprocessed/`` and writes a
corresponding file to ``news_data_summarized/`` containing a short summary of
each article.  It uses the ``sumy`` library to perform extractive
summarisation.  Only rows where the ``Mark`` column equals 1 are kept; all
others are dropped to remove irrelevant articles.

You can modify the number of sentences in the summary or the weighting of
keywords by changing the parameters in the ``main`` block.
"""

import os
import time
import pandas as pd
from collections import defaultdict
from sumy.summarizers.lsa import LsaSummarizer
from sumy.nlp.tokenizers import Tokenizer
from sumy.parsers.plaintext import PlaintextParser
from sumy.nlp.stemmers import Stemmer
from sumy.utils import get_stop_words


# Configure the summariser globally
_stemmer = Stemmer("english")
_summarizer = LsaSummarizer(_stemmer)
_tokenizer = Tokenizer("english")
_summarizer.stop_words = get_stop_words("english")


def _increase_weight_for_keywords(sentences, key_words):
    """Assign higher weights to sentences containing important keywords."""
    weights = defaultdict(float)
    for sentence in sentences:
        for word in key_words:
            if word.lower() in str(sentence).lower():
                weights[sentence] += 1
    return weights


def summarise_text(text: str, key_words: set, num_sentences: int) -> str:
    """Return a concise summary of ``text`` consisting of ``num_sentences``.

    Sentences containing any of the ``key_words`` are boosted so that they are
    more likely to appear in the summary.
    """
    parser = PlaintextParser.from_string(str(text), _tokenizer)
    initial_summary = list(_summarizer(parser.document, num_sentences))
    weights = _increase_weight_for_keywords(parser.document.sentences, key_words)
    # Give each sentence in the initial summary one extra weight unit
    for sentence in initial_summary:
        weights[sentence] += 1
    # Select the top weighted sentences
    ranked = sorted(weights, key=weights.get, reverse=True)[:num_sentences]
    return " ".join(str(sentence) for sentence in ranked)


def process_news_folder(folder_path: str, saving_path: str, num_sentences: int = 3) -> None:
    """Summarise all CSV files in ``folder_path`` and write to ``saving_path``."""
    os.makedirs(saving_path, exist_ok=True)
    csv_files = [f for f in os.listdir(folder_path) if f.endswith(".csv")]
    start = time.time()
    for csv_file in csv_files:
        file_path = os.path.join(folder_path, csv_file)
        print(f"Summarising {csv_file}...")
        try:
            df = pd.read_csv(file_path, encoding="utf-8")
        except UnicodeDecodeError:
            df = pd.read_csv(file_path, encoding="ISO-8859-1")
        # Normalise columns
        df.columns = df.columns.str.capitalize()
        symbol = csv_file.split(".")[0].upper()
        keywords = {symbol}
        # Drop irrelevant rows
        if 'Mark' in df.columns:
            df = df[df['Mark'] == 1].copy()
        if 'Text' not in df.columns:
            print(f"Skipping {csv_file}: no 'Text' column present")
            continue
        # Apply summarisation
        df['New_text'] = df['Text'].apply(lambda x: summarise_text(x, keywords, num_sentences))
        # Drop original text
        df = df.drop(columns=['Text'])
        out_path = os.path.join(saving_path, f"{symbol}.csv")
        df.to_csv(out_path, index=False)
        print(f"Saved summary to {out_path}")
    print(f"Finished summarisation in {time.time() - start:.2f}s")


if __name__ == "__main__":
    news_preprocessed = os.path.join(os.path.dirname(__file__), "news_data_preprocessed")
    news_summarized = os.path.join(os.path.dirname(__file__), "news_data_summarized")
    process_news_folder(news_preprocessed, news_summarized)