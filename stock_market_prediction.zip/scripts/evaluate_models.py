"""
Evaluate trained models on a held‑out test set and compute error metrics.

This script loads the merged dataset, creates input sequences, splits them
chronologically into training and test sets and computes metrics such as
mean absolute error (MAE), mean squared error (MSE) and the coefficient of
determination (R²).  Results are written to ``outputs/results/metrics_summary.csv``.
"""

import os
import json
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from typing import Dict, Callable

from src.data_processing import load_merged_data, create_sequences, train_test_split
from src.models import LSTMModel, GRUModel, TransformerModel


def load_model(model_type: str, config: Dict, device: torch.device):
    input_size = len(config['features'])
    if model_type == 'lstm':
        model = LSTMModel(input_size, config['hidden_size'], config['num_layers'], config.get('dropout', 0.0))
    elif model_type == 'gru':
        model = GRUModel(input_size, config['hidden_size'], config['num_layers'], config.get('dropout', 0.0))
    elif model_type == 'transformer':
        model = TransformerModel(
            input_size,
            d_model=config['d_model'],
            nhead=config['nhead'],
            num_layers=config['num_layers'],
            dim_feedforward=config.get('dim_feedforward', 256),
            dropout=config.get('dropout', 0.1),
        )
    else:
        raise ValueError(f"Unknown model type: {model_type}")
    model.to(device)
    return model


def evaluate_model(model: nn.Module, X_test: np.ndarray, y_test: np.ndarray, device: torch.device) -> Dict[str, float]:
    model.eval()
    with torch.no_grad():
        X_tensor = torch.tensor(X_test, dtype=torch.float32).to(device)
        y_tensor = torch.tensor(y_test, dtype=torch.float32).to(device)
        preds = model(X_tensor).cpu().numpy()
    mae = float(np.mean(np.abs(preds - y_test)))
    mse = float(np.mean((preds - y_test) ** 2))
    # Calculate R²: 1 - SSE/SST
    sse = np.sum((preds - y_test) ** 2)
    sst = np.sum((y_test - np.mean(y_test)) ** 2)
    r2 = float(1 - sse / sst) if sst != 0 else float('nan')
    return {"MAE": mae, "MSE": mse, "R2": r2}


def main():
    # Directory paths
    merged_dir = os.path.join(os.path.dirname(__file__), '..', 'data_processor', 'gpt_sentiment_price_news_integrate')
    models_dir = os.path.join(os.path.dirname(__file__), '..', 'outputs', 'models')
    configs_dir = os.path.join(os.path.dirname(__file__), '..', 'configs')
    results_dir = os.path.join(os.path.dirname(__file__), '..', 'outputs', 'results')
    os.makedirs(results_dir, exist_ok=True)
    data = load_merged_data(os.path.abspath(merged_dir))
    summary_records = []
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    for cfg_file in os.listdir(configs_dir):
        if not cfg_file.endswith('.yaml'):
            continue
        import yaml  # Local import to avoid requiring yaml if not evaluating
        cfg_path = os.path.join(configs_dir, cfg_file)
        with open(cfg_path, 'r') as f:
            cfg = yaml.safe_load(f)
        feature_columns = cfg['features']
        target_column = cfg['target']
        window_size = cfg['window_size']
        X, y = create_sequences(data, feature_columns, target_column, window_size)
        _, X_test, _, y_test = train_test_split(X, y, test_ratio=cfg.get('test_ratio', 0.2))
        model_type = cfg['model_type'].lower()
        model = load_model(model_type, cfg, device)
        model_path = os.path.join(models_dir, f"{model_type}_model.pth")
        if not os.path.isfile(model_path):
            print(f"Model weights not found for {model_type}, skipping evaluation")
            continue
        model.load_state_dict(torch.load(model_path, map_location=device))
        metrics = evaluate_model(model, X_test, y_test, device)
        summary_records.append({
            'Model': model_type,
            'MAE': metrics['MAE'],
            'MSE': metrics['MSE'],
            'R2': metrics['R2'],
        })
        print(f"Evaluated {model_type}: MAE={metrics['MAE']:.4f}, MSE={metrics['MSE']:.4f}, R2={metrics['R2']:.4f}")
    # Save summary to CSV
    summary_df = pd.DataFrame(summary_records)
    summary_df.to_csv(os.path.join(results_dir, 'metrics_summary.csv'), index=False)
    print(f"Saved evaluation metrics to {results_dir}/metrics_summary.csv")


if __name__ == "__main__":
    main()