"""
Generate plots comparing model predictions with actual values and summarising error metrics.

This script reads the evaluation results and produces two types of figures:

1. **Prediction vs Actual:** For each trained model, plot the first 100 samples of
   the test set, showing the actual target values and the model’s predictions.
2. **Metrics Comparison:** A bar chart comparing the MAE and MSE of each model.

The plots are saved into ``outputs/figures/``.
"""

import os
import yaml
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import torch

from src.data_processing import load_merged_data, create_sequences, train_test_split
from src.models import LSTMModel, GRUModel, TransformerModel


def load_model_and_predict(cfg_path: str, model_path: str, data: pd.DataFrame):
    with open(cfg_path, 'r') as f:
        cfg = yaml.safe_load(f)
    feature_columns = cfg['features']
    target_column = cfg['target']
    window_size = cfg['window_size']
    X, y = create_sequences(data, feature_columns, target_column, window_size)
    _, X_test, _, y_test = train_test_split(X, y, test_ratio=cfg.get('test_ratio', 0.2))
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    # Instantiate the correct model
    model_type = cfg['model_type'].lower()
    input_size = len(feature_columns)
    if model_type == 'lstm':
        model = LSTMModel(input_size, cfg['hidden_size'], cfg['num_layers'], cfg.get('dropout', 0.0))
    elif model_type == 'gru':
        model = GRUModel(input_size, cfg['hidden_size'], cfg['num_layers'], cfg.get('dropout', 0.0))
    elif model_type == 'transformer':
        model = TransformerModel(
            input_size,
            d_model=cfg['d_model'],
            nhead=cfg['nhead'],
            num_layers=cfg['num_layers'],
            dim_feedforward=cfg.get('dim_feedforward', 256),
            dropout=cfg.get('dropout', 0.1),
        )
    else:
        raise ValueError(f"Unknown model type: {model_type}")
    model.load_state_dict(torch.load(model_path, map_location=device))
    model.to(device)
    model.eval()
    with torch.no_grad():
        X_tensor = torch.tensor(X_test, dtype=torch.float32).to(device)
        preds = model(X_tensor).cpu().numpy()
    return preds, y_test


def main():
    root = os.path.dirname(__file__)
    merged_dir = os.path.join(root, '..', 'data_processor', 'gpt_sentiment_price_news_integrate')
    models_dir = os.path.join(root, '..', 'outputs', 'models')
    configs_dir = os.path.join(root, '..', 'configs')
    figures_dir = os.path.join(root, '..', 'outputs', 'figures')
    os.makedirs(figures_dir, exist_ok=True)
    data = load_merged_data(os.path.abspath(merged_dir))
    # 1. Prediction vs actual plots
    for cfg_file in os.listdir(configs_dir):
        if not cfg_file.endswith('.yaml'):
            continue
        model_type = cfg_file.split('_')[1].split('.')[0]  # e.g. config_lstm.yaml -> lstm
        model_path = os.path.join(models_dir, f"{model_type}_model.pth")
        if not os.path.isfile(model_path):
            continue
        cfg_path = os.path.join(configs_dir, cfg_file)
        preds, y_test = load_model_and_predict(cfg_path, model_path, data)
        # Plot first 100 samples
        n = min(100, len(y_test))
        plt.figure()
        plt.plot(range(n), y_test[:n], label='Actual')
        plt.plot(range(n), preds[:n], label='Predicted')
        plt.title(f'{model_type.upper()} Prediction vs Actual')
        plt.xlabel('Test Sample')
        plt.ylabel('Target')
        plt.legend()
        plt.tight_layout()
        fig_path = os.path.join(figures_dir, f'{model_type}_prediction_vs_actual.png')
        plt.savefig(fig_path)
        plt.close()
        print(f"Saved {fig_path}")
    # 2. Metrics comparison plot
    metrics_path = os.path.join(root, '..', 'outputs', 'results', 'metrics_summary.csv')
    if os.path.isfile(metrics_path):
        metrics_df = pd.read_csv(metrics_path)
        models = metrics_df['Model']
        mae = metrics_df['MAE']
        mse = metrics_df['MSE']
        x = np.arange(len(models))
        width = 0.35
        fig, ax = plt.subplots()
        ax.bar(x - width/2, mae, width, label='MAE')
        ax.bar(x + width/2, mse, width, label='MSE')
        ax.set_xticks(x)
        ax.set_xticklabels(models.str.upper())
        ax.set_ylabel('Error')
        ax.set_title('Model Error Comparison')
        ax.legend()
        plt.tight_layout()
        fig_path = os.path.join(figures_dir, 'model_comparison.png')
        plt.savefig(fig_path)
        plt.close()
        print(f"Saved {fig_path}")
    else:
        print("Metrics summary not found; skipping metrics plot")


if __name__ == '__main__':
    main()