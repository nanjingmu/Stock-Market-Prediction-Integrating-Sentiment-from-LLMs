"""
Train a time series model based on a YAML configuration file.

This script loads the merged dataset created by the data processor, creates
input sequences, splits them into train/test sets and trains the specified
model (LSTM, GRU or Transformer).  The training loop is intentionally
simple; you may wish to extend it with validation, early stopping or more
metrics.

Usage:

```bash
python scripts/train_models.py --config configs/config_lstm.yaml
```
"""

import argparse
import os
import yaml
from typing import Dict

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset

from src.data_processing import load_merged_data, create_sequences, train_test_split
from src.models import LSTMModel, GRUModel, TransformerModel


def load_config(path: str) -> Dict:
    with open(path, 'r') as f:
        return yaml.safe_load(f)


def train_model(config: Dict) -> None:
    # Load merged dataset
    merged_dir = os.path.join(os.path.dirname(__file__), '..', 'data_processor', 'gpt_sentiment_price_news_integrate')
    data = load_merged_data(os.path.abspath(merged_dir))
    # Create sequences
    feature_columns = config['features']
    target_column = config['target']
    window_size = config['window_size']
    X, y = create_sequences(data, feature_columns, target_column, window_size)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_ratio=config.get('test_ratio', 0.2))
    # Convert to tensors
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    X_train_tensor = torch.tensor(X_train, dtype=torch.float32).to(device)
    y_train_tensor = torch.tensor(y_train, dtype=torch.float32).to(device)
    train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
    train_loader = DataLoader(train_dataset, batch_size=config['batch_size'], shuffle=True)
    # Instantiate model
    input_size = len(feature_columns)
    model_type = config['model_type'].lower()
    if model_type == 'lstm':
        model = LSTMModel(input_size, config['hidden_size'], config['num_layers'], config.get('dropout', 0.0))
    elif model_type == 'gru':
        model = GRUModel(input_size, config['hidden_size'], config['num_layers'], config.get('dropout', 0.0))
    elif model_type == 'transformer':
        model = TransformerModel(
            input_size,
            d_model=config['d_model'],
            nhead=config['nhead'],
            num_layers=config['num_layers'],
            dim_feedforward=config.get('dim_feedforward', 256),
            dropout=config.get('dropout', 0.1),
        )
    else:
        raise ValueError(f"Unknown model_type: {model_type}")
    model.to(device)
    criterion = nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=config['learning_rate'])
    epochs = config['epochs']
    model.train()
    for epoch in range(1, epochs + 1):
        epoch_loss = 0.0
        for batch_X, batch_y in train_loader:
            optimizer.zero_grad()
            outputs = model(batch_X)
            loss = criterion(outputs, batch_y)
            loss.backward()
            optimizer.step()
            epoch_loss += loss.item() * batch_X.size(0)
        avg_loss = epoch_loss / len(train_loader.dataset)
        print(f"Epoch {epoch}/{epochs} - Train Loss: {avg_loss:.4f}")
    # Save model state_dict
    models_dir = os.path.join(os.path.dirname(__file__), '..', 'outputs', 'models')
    os.makedirs(models_dir, exist_ok=True)
    model_path = os.path.join(models_dir, f"{config['model_type']}_model.pth")
    torch.save(model.state_dict(), model_path)
    print(f"Saved trained model to {model_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train a time series model using configuration file")
    parser.add_argument('--config', type=str, required=True, help='Path to YAML configuration file')
    args = parser.parse_args()
    cfg = load_config(args.config)
    train_model(cfg)