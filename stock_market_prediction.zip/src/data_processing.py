"""
Utility functions for preparing data for time series models.

This module defines helpers to load merged price/sentiment CSVs and create
input sequences suitable for training recurrent or attention‑based neural
networks.  You can customise the sequence length and which columns to use
as features and targets.
"""

import os
from typing import List, Tuple

import numpy as np
import pandas as pd


def load_merged_data(folder: str) -> pd.DataFrame:
    """Concatenate all CSVs in `folder` into a single DataFrame.

    Each CSV should have the same columns (e.g. Date, Close, Scaled_sentiment, News_flag).  The function drops the Date column
    after sorting chronologically and concatenating the data.
    """
    data_frames: List[pd.DataFrame] = []
    for file in os.listdir(folder):
        if file.endswith('.csv'):
            df = pd.read_csv(os.path.join(folder, file))
            data_frames.append(df)
    if not data_frames:
        raise FileNotFoundError(f"No CSV files found in {folder}")
    # Concatenate and sort
    merged = pd.concat(data_frames, ignore_index=True)
    merged['Date'] = pd.to_datetime(merged['Date'])
    merged.sort_values(by='Date', inplace=True)
    return merged


def create_sequences(
    data: pd.DataFrame,
    feature_columns: List[str],
    target_column: str,
    window_size: int,
) -> Tuple[np.ndarray, np.ndarray]:
    """Transform a DataFrame into sequences for supervised learning.

    Returns arrays ``X`` and ``y`` where ``X`` has shape ``(num_samples, window_size, num_features)`` and ``y`` has shape ``(num_samples,)``.  The target is taken from ``target_column`` shifted by one time step relative to the end of each input window.
    """
    values = data[feature_columns + [target_column]].to_numpy(dtype=float)
    num_samples = len(values) - window_size
    if num_samples <= 0:
        raise ValueError("Not enough data to create sequences")
    X = np.zeros((num_samples, window_size, len(feature_columns)), dtype=float)
    y = np.zeros(num_samples, dtype=float)
    for i in range(num_samples):
        X[i] = values[i : i + window_size, : len(feature_columns)]
        y[i] = values[i + window_size, len(feature_columns)]
    return X, y


def train_test_split(X: np.ndarray, y: np.ndarray, test_ratio: float = 0.2) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Split the sequence data into training and test sets chronologically."""
    split_index = int(len(X) * (1 - test_ratio))
    X_train, X_test = X[:split_index], X[split_index:]
    y_train, y_test = y[:split_index], y[split_index:]
    return X_train, X_test, y_train, y_test