"""
PyTorch implementation of a simple GRU network for time series prediction.

Similar to the LSTM model but using gated recurrent units which have fewer
parameters and may train faster.
"""

import torch
import torch.nn as nn


class GRUModel(nn.Module):
    def __init__(self, input_size: int, hidden_size: int, num_layers: int, dropout: float = 0.0):
        super().__init__()
        self.gru = nn.GRU(input_size, hidden_size, num_layers, batch_first=True, dropout=dropout)
        self.fc = nn.Linear(hidden_size, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (batch_size, seq_len, input_size)
        out, _ = self.gru(x)
        last_hidden = out[:, -1, :]
        return self.fc(last_hidden).squeeze(-1)