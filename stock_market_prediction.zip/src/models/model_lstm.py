"""
PyTorch implementation of a simple LSTM network for time series prediction.

The model expects input of shape (batch_size, seq_len, num_features) and
produces a single scalar output per sequence (e.g. next closing price).
"""

import torch
import torch.nn as nn


class LSTMModel(nn.Module):
    def __init__(self, input_size: int, hidden_size: int, num_layers: int, dropout: float = 0.0):
        super().__init__()
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True, dropout=dropout)
        self.fc = nn.Linear(hidden_size, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (batch_size, seq_len, input_size)
        out, _ = self.lstm(x)
        # Use the last hidden state of the last layer
        last_hidden = out[:, -1, :]
        return self.fc(last_hidden).squeeze(-1)